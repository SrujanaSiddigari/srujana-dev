<?php
/**
 * Plugin Name: My First Plugin
 * Plugin URI: http://localhost/coete/myplugin
 * Description: The very first plugin that I have ever created.
 * Version: 1.0
 * Author: Srujana
 * Author URI: http://localhost/coete
 */
?>
<?php
add_action('admin_menu', 'email_plugin_setup_menu');
 
function email_plugin_setup_menu(){
        add_menu_page( 'Email-Plugin page', 'My First Plugin', 'manage_options', 'email-plugin-page', 'upload' );
}
function upload(){
  echo "this is my plugin..";
  include 'connectdb.php';

$result = mysql_query("SELECT * FROM emails");
echo "<table border='1'>
<tr>
<th>sno</th>
<th>NAme</th>
<th>Phone</th>
<th>Message</th>
<th colspan=2>Email status</th>
</tr>";
$no=1;
$status;
while($row = mysql_fetch_array($result))
{
echo "<tr>";
echo "<td>" . $no . "</td>";
echo "<td>" . $row['name'] . "</td>";
echo "<td>" . $row['phone'] . "</td>";
echo "<td>" . $row['message'] . "</td>";
$status = $row['emailstatus']  ."</td>";
if($status == 1){
  echo "<td>" . "email has been received" . "</td>";
}
else{
  echo "<td>" . "email sent failed" . "</td>";

}
echo "</tr>";
$no++;
}

echo "</table>";
}
wp_register_script( 'js', 'http://localhost/coete/wp-content/plugins/sendemails/js/validate.js');
wp_enqueue_script( 'jquery' );
wp_enqueue_script( 'js' );

 wp_register_script( 'style', 'http://localhost/coete/wp-content/plugins/sendemails/css/style.css');
 wp_enqueue_script( 'style' );

function form_creation(){
  $html = "<form id='formid' method='post'>";
  $html .= "<input type='text' name='nam' size='30' placeholder='enter name'>".'<br>';
  $html .= "<input type='text' maxlength='10' name='phone' size='30' placeholder='enter phone'>".'<br>';
  $html .= "<input type='text' name='msg' size='30' placeholder='enter message'>".'<br>';
  $html .= "<button name='btn' type='submit' class='btn btn-success'>Send";
  $html .="</button>";
  $html .= "</form>";
  return $html;
}
emails();
?>
<?php
  function emails(){
    $to="siddigarisru@gmail.com";
    //echo $to;
  // Always set content-type when sending HTML email
$headers = "From: bhoomi@gkblabs.com" . "\r\n";
 if(isset($_POST['btn'])){
    $name=$_POST['nam']; 
    echo $name;
    $phone=$_POST['phone'];
    echo $phone;
    $usrmsg=$_POST['msg'];
    include 'connectdb.php';

    if(mail($to,"some subject",$txt,$headers))
    {
      echo "mail sent";
      $status=1;
    }
    else
    {
      echo "mail failed";
      $status=0;
    }
    echo $status;
    $sql = "INSERT INTO emails(name, phone,message,emailstatus)
    VALUES ('$name', '$phone', '$usrmsg','$status')";
    $sql_exe=mysql_query($sql) or die(mysql_error());
    $txt= $name . "\n" . $phone ."\n". $usrmsg ."\n".$status."\n";
}
  }
add_shortcode("test", "form_creation");
?>