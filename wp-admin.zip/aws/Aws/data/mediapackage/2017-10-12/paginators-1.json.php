<?php
// This file was auto-generated from sdk-root/src/data/mediapackage/2017-10-12/paginators-1.json
return [ 'pagination' => [ 'ListChannels' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', 'result_key' => 'Channels', ], 'ListOriginEndpoints' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', 'result_key' => 'OriginEndpoints', ], ],];
